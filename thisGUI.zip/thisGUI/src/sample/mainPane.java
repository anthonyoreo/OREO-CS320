package sample;

import javafx.scene.layout.AnchorPane;


public class mainPane extends AnchorPane {

;
}
